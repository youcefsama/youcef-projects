Chat php/ajax/mysql-------------------
Url     : http://codes-sources.commentcamarche.net/source/54910-chat-php-ajax-mysqlAuteur  : bebert2310Date    : 05/08/2013
Licence :
=========

Ce document intitul� � Chat php/ajax/mysql � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Voil&agrave; un petit chat en PHP, AJAX et MySQL. Il marche plut&ocirc;t bien, g
&egrave;re les smiley ...
<br />Une fois t&eacute;l&eacute;charg&eacute; ouvrez
 le fichier &quot;lisez-moi.txt&quot; et suivez les instructions.
<br />d&eacut
e;mo sur : <a href='http://minichat.uphero.com/' target='_blank'>http://minichat
.uphero.com/</a>
